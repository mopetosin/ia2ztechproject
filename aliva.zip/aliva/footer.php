<!-- jQuery --> 
<script type="text/javascript" src="js/jquery.js"></script>

<!-- COMPRESSED -->
<script type="text/javascript" src="js/compressed.js"></script>

<!-- Parallax & Animations -->
<script type="text/javascript" src="js/animations.js"></script>

<!-- FUNCTIONS -->
<script type="text/javascript" src="js/functions.js"></script>

<!-- Including all compiled Bootstrap plugins  --> 
<script type="text/javascript" src="js/bootstrap.min.js"></script>
